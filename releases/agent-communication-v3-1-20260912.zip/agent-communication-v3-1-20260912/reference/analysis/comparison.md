# 여섯 방식 비교표 · 사후 검수 v3.1

같은 문제·Luna high·방식별5회·병렬 jobs=6. 아래는 기존30회 원본의 관측값이며 실험을 재실행하지 않았다.

[종합 인사이트](../../../docs/experiment-insights-v3-1.md) · [계산 원자료](comparison.json) · [30회별 계산](trials.json) · [재현 코드](derive.py)

## 성공·품질과 비용

성공은 동일한 유효 일정의 공동 제출이다. 최적 점수20 도달은 별도다. 성공당 모델 비용은 실패·사전 합의·거절된 요청까지 포함한5회 전체 모델 비용 ÷ 성공 수다.

| 방식 | 성공 / 5 | 최적 / 5 | 회차별 점수 | 성공한 회차 평균 최적 차이 | 모델 비용 합계 USD | 성공당 모델 비용 USD | 성공당 총비용 |
|---|---|---|---|---|---|---|---|
| [1 자연어](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-01-natural-language/README.md) | 5 | 4 | 20, 20, 18, 20, 20 | 0.40 | 0.031270 | 0.006254 | 미측정 |
| [2 JSON](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-02-json/README.md) | 5 | 5 | 20, 20, 20, 20, 20 | 0.00 | 0.057007 | 0.011401 | 미측정 |
| [3 제한된 논리식·관계 표현](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-03-relations/README.md) | 4 | 4 | 20, 20, 20, 무효, 20 | 0.00 | 0.049967 | 0.012492 | 미측정 |
| [4 고정 의미 특성 벡터](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-04-feature-vector/README.md) | 5 | 5 | 20, 20, 20, 20, 20 | 0.00 | 0.058065 | 0.011613 | 미측정 |
| [5 제한된 바이트코드](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-05-bytecode/README.md) | 5 | 5 | 20, 20, 20, 20, 20 | 0.00 | 0.054378 | 0.010876 | 미측정 |
| [6 고정 문법에서 기호 사전 합의](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-06-shared-dictionary/README.md) | 5 | 5 | 20, 20, 20, 20, 20 | 0.00 | 0.112804 | 0.022561 | 미측정 |

단가는 실행 manifest에 고정된 입력 $0.20·캐시 입력 $0.02·출력 $1.20/백만 토큰을 재사용했다. 현재 가격을 새로 조회한 결과나 실제 구독 청구액이 아니다. 통신 처리 금액과 성공당 총비용은 모든 방식에서 미측정이다.

## 시간 분포

회차 시간은 초기화부터 결과 기록까지의 원래 측정 경계다. 요청 전체1137.20초에는 worktree 준비·조정기 대기·취합도 포함되며 아래 회차 시간의 합과 다르다.

| 방식 | 전체5회 평균 초 | 전체5회 중앙값 초 | 범위 초 | 성공 회차 평균 초 | 전체 요청 수 | 형식·행동 거절 |
|---|---|---|---|---|---|---|
| [1 자연어](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-01-natural-language/README.md) | 75.24 | 68.34 | 65.90–87.85 | 75.24 | 25 | 0 |
| [2 JSON](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-02-json/README.md) | 133.70 | 131.96 | 97.74–169.84 | 133.70 | 26 | 0 |
| [3 제한된 논리식·관계 표현](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-03-relations/README.md) | 117.28 | 132.57 | 83.07–145.57 | 125.83 | 29 | 1 |
| [4 고정 의미 특성 벡터](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-04-feature-vector/README.md) | 122.71 | 128.74 | 86.04–156.07 | 122.71 | 29 | 0 |
| [5 제한된 바이트코드](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-05-bytecode/README.md) | 118.84 | 124.57 | 81.40–157.74 | 118.84 | 32 | 1 |
| [6 고정 문법에서 기호 사전 합의](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-06-shared-dictionary/README.md) | 204.48 | 171.88 | 81.72–465.52 | 204.48 | 84 | 33 |

3단계의 빠른 실패83.07초가 전체 평균을 낮춘다. 실패를 성공 완료 시간으로 읽지 않도록 두 평균을 분리했다. 모델 요청 수는 실행기가 요청한turn 수이며 공급자 내부 호출 수는 아니다.

## 통신량과 로컬 처리

바이트는 실험 채널의 실제 본문과 헤더다. 모델 API·TLS/IP 전체 트래픽이나 로그 base64 크기는 포함하지 않는다. CPU는 전송·복원·프레이밍과 기록된 실패 변환의 처리 합계이며 모델의 문제 풀이·메시지 생성 시간과 다르다.

| 방식 | 작업 메시지 합계 | 합의 메시지 합계 | 본문 평균 B/회 | 헤더 평균 B/회 | 채널 합계 평균 B/회 | 수신 텍스트 평균 B/회 | 통신 CPU 평균 ms/회 |
|---|---|---|---|---|---|---|---|
| [1 자연어](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-01-natural-language/README.md) | 15 | 0 | 873.2 | 342.0 | 1215.2 | 873.2 | 0.174 |
| [2 JSON](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-02-json/README.md) | 16 | 0 | 4839.4 | 366.8 | 5206.2 | 4839.4 | 0.875 |
| [3 제한된 논리식·관계 표현](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-03-relations/README.md) | 18 | 0 | 2803.4 | 410.0 | 3213.4 | 2803.4 | 1.763 |
| [4 고정 의미 특성 벡터](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-04-feature-vector/README.md) | 19 | 0 | 124537.4 | 440.8 | 124978.2 | 3562.0 | 14.149 |
| [5 제한된 바이트코드](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-05-bytecode/README.md) | 21 | 0 | 645.0 | 476.4 | 1121.4 | 4122.8 | 1.395 |
| [6 고정 문법에서 기호 사전 합의](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-06-shared-dictionary/README.md) | 29 | 10 | 3635.6 | 907.2 | 4542.8 | 2776.6 | 3.917 |

6단계 채널 합계에는 합의 메시지가 포함되며, 수신 텍스트 열은 모든 방식에서 작업 메시지만이다. 합의·반복 대화의 모델 사용량은 다음 표의 전체 토큰에 포함된다.

## 모델 토큰과 캐시 민감도

아래 토큰은 A·B 전체 요청 누적 사용량의 회차 평균이다. 입력에는 캐시 입력이 이미 포함되며 reasoning은 출력에 포함된다.

| 방식 | 입력 평균 | 캐시 입력 평균 | 출력 평균 | 입력 중 캐시 비중 | 관측 성공당 모델 비용 USD | 캐시 할인 없는 가상 재가중 USD/성공 |
|---|---|---|---|---|---|---|
| [1 자연어](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-01-natural-language/README.md) | 30464.2 | 15462.4 | 2453.6 | 50.8% | 0.006254 | 0.009037 |
| [2 JSON](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-02-json/README.md) | 42992.6 | 21708.8 | 5592.0 | 50.5% | 0.011401 | 0.015309 |
| [3 제한된 논리식·관계 표현](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-03-relations/README.md) | 44230.6 | 25139.2 | 4727.0 | 56.8% | 0.012492 | 0.018148 |
| [4 고정 의미 특성 벡터](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-04-feature-vector/README.md) | 47216.4 | 21657.6 | 5056.8 | 45.9% | 0.011613 | 0.015511 |
| [5 제한된 바이트코드](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-05-bytecode/README.md) | 50630.4 | 27545.6 | 4756.4 | 54.4% | 0.010876 | 0.015834 |
| [6 고정 문법에서 기호 사전 합의](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-06-shared-dictionary/README.md) | 188920.4 | 141721.6 | 8572.2 | 75.0% | 0.022561 | 0.048071 |

가상 재가중은 동일 토큰의 캐시 할인만 제거한 산술 민감도다. 실제 캐시를 끄고 실행한 결과나 그때의 시간·성공률 예측이 아니다. 첫 호출부터 캐시가 기록된 세션은20/60개다. 새 대화 세션이 서버 캐시와 공유 부하까지 격리했다는 뜻은 아니다.

## 내용 검수와 실제 행동

자연어는 원문에 근거한AI 전수 주석과 별도AI 재검수, 구조화 표현은 고정 의미의 자동 평가다. 사람의 독립 검수는 대기다. 자연어 추가 자유 표현·반복·슬롯별 전개 때문에 총분모와 오류 개수를 그대로 정확도 순위로 사용하지 않는다.

| 방식 | 명시 주장 | 맞음 | 틀림 | 규약 보류 | 모호한 표현 | 내용 오류 회차 | 명시적 revise |
|---|---|---|---|---|---|---|---|
| [1 자연어](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-01-natural-language/README.md) | 529 | 523 | 6 | 0 | 1 | 2, 3, 4, 5 | 0 |
| [2 JSON](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-02-json/README.md) | 656 | 652 | 4 | 0 | 0 | 2, 4 | 0 |
| [3 제한된 논리식·관계 표현](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-03-relations/README.md) | 522 | 514 | 4 | 4 | 0 | 1, 5 | 0 |
| [4 고정 의미 특성 벡터](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-04-feature-vector/README.md) | 553 | 546 | 3 | 4 | 0 | 1, 5 | 1 |
| [5 제한된 바이트코드](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-05-bytecode/README.md) | 589 | 588 | 1 | 0 | 0 | 1 | 0 |
| [6 고정 문법에서 기호 사전 합의](../../readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-06-shared-dictionary/README.md) | 660 | 631 | 29 | 0 | 0 | 3, 5 | 1 |

코덱 보존 오류는30회 모두0건이다. 3단계 실패 회차에는 전달된 명시 주장 오류가0건이지만 최종 일정이 무효였다. 제안 배치는 검증할 후보이며, 그 자체로 유효성·최적성 주장을 추가하지 않는 검수 규칙에 따른다.

## 30회 개별 결과

아래5회 모두를 각 방식의 집계에 포함했다. 느린 회차나 실패를 삭제하지 않았다.

| 단계 | 회차 | 결과 | 점수 | 시간 초 | 모델 비용 USD | 요청 | 거절 | 채널 B | 내용 오류 |
|---|---|---|---|---|---|---|---|---|---|
| 1 | [1](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-01-natural-language/trial-01/transcript.md) | success | 20 | 86.66 | 0.007993 | 5 | 0 | 1420 | 0 |
| 1 | [2](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-01-natural-language/trial-02/transcript.md) | success | 20 | 67.47 | 0.005561 | 4 | 0 | 783 | 1 |
| 1 | [3](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-01-natural-language/trial-03/transcript.md) | success | 18 | 68.34 | 0.005065 | 5 | 0 | 1127 | 3 |
| 1 | [4](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-01-natural-language/trial-04/transcript.md) | success | 20 | 87.85 | 0.006786 | 5 | 0 | 1466 | 1 |
| 1 | [5](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-01-natural-language/trial-05/transcript.md) | success | 20 | 65.90 | 0.005865 | 6 | 0 | 1280 | 1 |
| 2 | [1](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-02-json/trial-01/transcript.md) | success | 20 | 131.26 | 0.011476 | 5 | 0 | 4803 | 0 |
| 2 | [2](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-02-json/trial-02/transcript.md) | success | 20 | 169.84 | 0.013404 | 6 | 0 | 6150 | 2 |
| 2 | [3](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-02-json/trial-03/transcript.md) | success | 20 | 131.96 | 0.012380 | 5 | 0 | 4779 | 0 |
| 2 | [4](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-02-json/trial-04/transcript.md) | success | 20 | 97.74 | 0.008625 | 5 | 0 | 2953 | 2 |
| 2 | [5](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-02-json/trial-05/transcript.md) | success | 20 | 137.68 | 0.011122 | 5 | 0 | 7346 | 0 |
| 3 | [1](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-03-relations/trial-01/transcript.md) | success | 20 | 140.55 | 0.012221 | 7 | 1 | 4219 | 1 |
| 3 | [2](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-03-relations/trial-02/transcript.md) | success | 20 | 145.57 | 0.014403 | 7 | 0 | 3068 | 0 |
| 3 | [3](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-03-relations/trial-03/transcript.md) | success | 20 | 84.64 | 0.006303 | 5 | 0 | 2279 | 0 |
| 3 | [4](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-03-relations/trial-04/transcript.md) | failed | 무효 | 83.07 | 0.006706 | 5 | 0 | 2279 | 0 |
| 3 | [5](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-03-relations/trial-05/transcript.md) | success | 20 | 132.57 | 0.010334 | 5 | 0 | 4222 | 3 |
| 4 | [1](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-04-feature-vector/trial-01/transcript.md) | success | 20 | 135.35 | 0.014115 | 5 | 0 | 98667 | 1 |
| 4 | [2](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-04-feature-vector/trial-02/transcript.md) | success | 20 | 156.07 | 0.014460 | 8 | 0 | 197334 | 0 |
| 4 | [3](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-04-feature-vector/trial-03/transcript.md) | success | 20 | 107.36 | 0.010798 | 5 | 0 | 98667 | 0 |
| 4 | [4](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-04-feature-vector/trial-04/transcript.md) | success | 20 | 86.04 | 0.007210 | 5 | 0 | 98667 | 0 |
| 4 | [5](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-04-feature-vector/trial-05/transcript.md) | success | 20 | 128.74 | 0.011481 | 6 | 0 | 131556 | 2 |
| 5 | [1](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-05-bytecode/trial-01/transcript.md) | success | 20 | 134.82 | 0.012215 | 5 | 0 | 1031 | 1 |
| 5 | [2](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-05-bytecode/trial-02/transcript.md) | success | 20 | 95.66 | 0.008406 | 5 | 0 | 736 | 0 |
| 5 | [3](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-05-bytecode/trial-03/transcript.md) | success | 20 | 81.40 | 0.006872 | 5 | 0 | 736 | 0 |
| 5 | [4](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-05-bytecode/trial-04/transcript.md) | success | 20 | 157.74 | 0.015565 | 9 | 0 | 1902 | 0 |
| 5 | [5](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-05-bytecode/trial-05/transcript.md) | success | 20 | 124.57 | 0.011320 | 8 | 1 | 1202 | 0 |
| 6 | [1](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-06-shared-dictionary/trial-01/transcript.md) | success | 20 | 115.58 | 0.011921 | 8 | 0 | 3754 | 0 |
| 6 | [2](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-06-shared-dictionary/trial-02/transcript.md) | success | 20 | 81.72 | 0.010263 | 7 | 0 | 2601 | 0 |
| 6 | [3](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-06-shared-dictionary/trial-03/transcript.md) | success | 20 | 187.69 | 0.018135 | 10 | 1 | 5267 | 13 |
| 6 | [4](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-06-shared-dictionary/trial-04/transcript.md) | success | 20 | 465.52 | 0.055276 | 47 | 31 | 5486 | 0 |
| 6 | [5](/Users/hyohyeon/Desktop/agent-research-commincation/results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/stage-06-shared-dictionary/trial-05/transcript.md) | success | 20 | 171.88 | 0.017211 | 12 | 1 | 5606 | 16 |
