"""Verify this report against preserved originals and the selected review version."""
import hashlib
import json
import math
import re
import statistics
import subprocess
import sys
from datetime import datetime,timezone
from pathlib import Path
from urllib.parse import unquote
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
sys.path.insert(0,str(ROOT))
from experiment.artifacts import source_snapshot

def read(p):return json.loads(p.read_text())
def hashes(p):return {str(x.relative_to(p)):hashlib.sha256(x.read_bytes()).hexdigest() for x in sorted(p.rglob('*')) if x.is_file()}
def close(a,b):assert math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-9),(a,b)

before=read(HERE/'preservation-before.json');preserved={}
for folder,expected in before['folders'].items():
 actual=hashes(ROOT/folder)
 assert actual==expected,('original changed',folder)
 preserved[folder]={'files':len(expected),'identical':True}
assert source_snapshot()==before['source_snapshot']
data=read(HERE/'comparison.json');trials=read(HERE/'trials.json');cases=read(HERE/'case-evidence.json')
selected=read(Path(data['selected_collection']))
assert len(trials)==30 and len(data['stages'])==6
for relative,digest in data['source_files'].items():assert hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()==digest
for s,rec in zip(data['stages'],selected['records']):
 rows=[r for r in trials if r['stage']==s['stage']]
 originals=[read(Path(rec['source'])/('trial-%02d'%i)/'result.json') for i in range(1,6)]
 assert len(rows)==5 and [r['trial'] for r in rows]==list(range(1,6))
 assert s['success_count']==sum(r['success'] for r in originals)
 assert s['optimal_count']==sum(r['success'] and r['quality_gap']==0 for r in originals)
 for field,values in [('elapsed_seconds',[r['elapsed_seconds'] for r in originals]),('communication_bytes',[r['communication_bytes'] for r in originals]),('protocol_cpu_seconds',[r['protocol_cpu_seconds'] for r in originals]),('model_cost_estimate_usd',[r['model_cost_estimate_usd'] for r in originals])]:
  close(s['stats'][field]['mean'],statistics.mean(values));close(s['stats'][field]['median'],statistics.median(values))
 close(s['model_cost_per_success_usd'],sum(r['model_cost_estimate_usd'] for r in originals)/sum(r['success'] for r in originals))
 close(s['model_cost_per_success_usd'],rec['summary']['model_cost_per_success_estimate_usd'])
 for row,original in zip(rows,originals):
  obs=read(Path(row['review'])/'observation.json')
  for key in ('correct_claims','incorrect_claims','undetermined_claims','unjudgeable_expressions'):assert row[key]==obs[key]
  assert row['score']==original['evaluation']['score'] and row['success']==original['success']
  close(sum(x['model_cost_estimate_usd'] for x in row['per_request']),original['model_cost_estimate_usd'])
  assert len(row['per_request'])==original['actions']
  assert row['total_cost_estimate_usd'] is None and row['communication_processing_cost_estimate_usd'] is None

# Verify the source excerpts, including the line reference, are exact records.
case_event_count=0
for case in cases:
 events=[json.loads(line) for line in Path(case['source_events']).read_text().splitlines()]
 for item in case['events']:
  original=events[item['source_line']-1]
  assert {k:item[k] for k in ('method','recorded_at','params')}=={k:original[k] for k in ('method','recorded_at','params')}
  case_event_count+=1

# Assertions underpinning the causal boundaries in the prose report.
vector=[t for t in trials if t['stage']==4]
assert sum(len(t['task_payload_sizes']) for t in vector)==19
assert {n for t in vector for n in t['task_payload_sizes']}=={32773}
assert sum(t['first_calls_with_cache'] for t in trials)==20
assert sum(t['explicit_revisions'] for t in trials)==2
assert sum(t['explicit_recheck_ids'] for t in trials if t['stage']>1)==0
s6t4=next(t for t in trials if (t['stage'],t['trial'])==(6,4))
assert s6t4['protocol_errors']==31 and s6t4['incorrect_claims']==0
assert round(s6t4['rejected_request_seconds'],2)==264.26
assert round(s6t4['rejected_request_model_cost_usd'],6)==.031554
s6t3=next(c for c in cases if (c['stage'],c['trial'])==(6,3))
a=next(m for m in s6t3['messages'] if m['message']==3);b=next(m for m in s6t3['messages'] if m['message']==5)
a={tuple(c['value'][:-1]):c for c in a['claims'] if c['type']=='summary'}
b={tuple(c['value'][:-1]):c for c in b['claims'] if c['type']=='summary'}
corrected=sum(a[k]['correct'] is False and b[k]['correct'] is True for k in a.keys()&b.keys())
introduced=sum(a[k]['correct'] is True and b[k]['correct'] is False for k in a.keys()&b.keys())
assert (corrected,introduced)==(8,4)

# The summary table in the manually written report must match generated full precision data.
report=ROOT/'docs/experiment-insights-v3-1.md'
rows=[line for line in report.read_text().splitlines() if re.match(r'^\| [1-6] ',line)]
assert len(rows)==6
for row,s in zip(rows,data['stages']):
 cells=[x.strip() for x in row.strip('|').split('|')]
 expected=[f"{s['success_count']}/5",f"{s['optimal_count']}/5",f"{s['model_cost_per_success_usd']:.6f}",f"{s['termination_seconds_all']['mean']:.2f}",f"{s['termination_seconds_all']['median']:.2f}",f"{s['stats']['communication_bytes']['mean']:,.1f}",f"{s['stats']['protocol_cpu_seconds']['mean']*1000:.3f}"]
 assert cells[1:]==expected,(cells,expected)

# Record the existing read-only CLI comparison, without invoking any run command.
proc=subprocess.run([sys.executable,'lab.py','compare'],cwd=ROOT,capture_output=True,text=True,check=True)
(HERE/'compare-cli.txt').write_text(proc.stdout)
assert proc.stdout.count('동일 조건 그룹:')==1
assert proc.stdout.count('  시도 5개')==6

validation={'checked_at':datetime.now(timezone.utc).isoformat(),'experiment_reruns':0,'runtime_source_unchanged':True,
 'preservation':preserved,'original_files_preserved':sum(v['files'] for v in preserved.values()),
 'source_input_hashes_verified':len(data['source_files']),
 'trials':30,'original_successes':29,'original_optimal':28,'requests':225,'packets':128,
 'selected_review_policy':'observation-review-v3.1','content_errors':47,'undetermined_score_claims':8,
 'natural_language_ambiguous_expressions':1,'independent_human_review':'pending',
 'same_condition_cli_groups':1,'case_event_records_verified':case_event_count,
 's6t3_corrected_summary_items':corrected,'s6t3_newly_wrong_summary_items':introduced,
 'summary_table_matches_full_precision_data':True}
(HERE/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
files=list((ROOT/'docs').glob('*.md'))+[ROOT/'README.md',ROOT/'results/README.md']+list(HERE.glob('*.md'))
missing=[];links=0
for p in files:
 for dest in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  dest=dest.split('#')[0].strip('<>')
  if not dest or '://' in dest:continue
  target=(p.parent/unquote(dest)).resolve()
  if not target.exists():missing.append((str(p.relative_to(ROOT)),dest))
  links+=1
assert not missing,missing
validation.update(markdown_files_checked=len(files),local_links_checked=links,missing_links=[])
(HERE/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(validation,ensure_ascii=False,indent=2))
