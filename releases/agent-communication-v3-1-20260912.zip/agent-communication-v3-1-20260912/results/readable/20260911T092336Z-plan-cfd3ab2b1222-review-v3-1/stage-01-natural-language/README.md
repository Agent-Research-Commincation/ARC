# 단계별 실험 기록

방식: 자연어

[지표 보고서](report.md)

검수 버전: 20260911T104427Z-review-fd3b7152b76b

사후 평가 정책: observation-review-v3.1

`source-report.md`는 종료 당시 보고서 원문이고, `report.md`는 수치를 유지한 채 요청/턴의 단위명을 정리한 표시용 사본입니다. 최신 내용 검수 상태는 아래 관찰표와 선택한 검수 버전을 기준으로 합니다. AI 주석 검수와 사람의 독립 검수는 구별합니다.

| 회차 | 상태 | 관찰 | 대화 | Agent 이력 |
|---|---|---|---|---|
| 1 | success | [관찰](trial-01/observation.md) | [대화](trial-01/transcript.md) | [A](trial-01/Agent_A.md) · [B](trial-01/Agent_B.md) |
| 2 | success | [관찰](trial-02/observation.md) | [대화](trial-02/transcript.md) | [A](trial-02/Agent_A.md) · [B](trial-02/Agent_B.md) |
| 3 | success | [관찰](trial-03/observation.md) | [대화](trial-03/transcript.md) | [A](trial-03/Agent_A.md) · [B](trial-03/Agent_B.md) |
| 4 | success | [관찰](trial-04/observation.md) | [대화](trial-04/transcript.md) | [A](trial-04/Agent_A.md) · [B](trial-04/Agent_B.md) |
| 5 | success | [관찰](trial-05/observation.md) | [대화](trial-05/transcript.md) | [A](trial-05/Agent_A.md) · [B](trial-05/Agent_B.md) |

## 선택한 평가 재현

`source/`는 실험 실행 코드, `selected-review/evaluation-source/`는 사후 평가 코드입니다.

`python3 replay_review.py --export . --output <새 출력 폴더>`로 선택한 주석의 판정과 관찰표를 재현합니다. 모델을 호출하지 않습니다. 자연어 의미를 새로 독립 주석하는 작업은 아닙니다.

[평가 버전·주석 정보](selected-review/manifest.json) · [평가 집계](selected-review/summary.json)
