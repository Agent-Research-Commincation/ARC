# 자연어의 명시 오류·누락·모호함

현재 기준의 명시 오류는 6건이다. 별도로 가능한 시간 목록에서 슬롯 8이 빠진 항목 4개와 모호한 표현 1개가 있다. 누락을 자동으로 오류로 합산하지 않는다.

아래 네 목록만 전체 목록 주장으로 해석하면 오류가 10건이 되는 대안이 있다. 전체 자연어를 다시 주석한 결과나 새로운 정확도 비율은 아니다. 해당 슬롯은 B1의 제약으로 전체 일정에 사용할 수 없어 최종 성공·최적 수는 변하지 않는다.

| 회차 | 메시지 | 회의 | 빠진 가능 슬롯 | 원문 |
|---|---|---|---|---|
| 1 | 1 | M1 | 8 | [대화](stage-01-natural-language/trial-01/transcript.md) |
| 1 | 1 | M2 | 8 | [대화](stage-01-natural-language/trial-01/transcript.md) |
| 4 | 2 | M1 | 8 | [대화](stage-01-natural-language/trial-04/transcript.md) |
| 4 | 2 | M2 | 8 | [대화](stage-01-natural-language/trial-04/transcript.md) |

[상세 근거](language-sensitivity.json) · [평가 범위](../../../docs/metrics.md)

새 실험에서는 목록의 의미와 불가능 후보 점수 기준을 결과 확인 전에 고정한다. 기존 판정 재현과 독립적인 의미 주석은 별개다.
