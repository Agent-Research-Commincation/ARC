# 방식별·회차별 대화

[전체 비교표](../../analysis/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/comparison.md) · [자연어 전체 기록](natural-language-review.md) · [누락·해석 민감도](language-sensitivity.md)

| 방식 | 실제 대화와 평가 |
|---|---|
| 1 · 자연어 | [5회 기록](stage-01-natural-language/README.md) |
| 2 · JSON | [5회 기록](stage-02-json/README.md) |
| 3 · 제한된 논리식·관계 표현 | [5회 기록](stage-03-relations/README.md) |
| 4 · 고정 의미 특성 벡터 | [5회 기록](stage-04-feature-vector/README.md) |
| 5 · 제한된 바이트코드 | [5회 기록](stage-05-bytecode/README.md) |
| 6 · 고정 문법에서 기호 사전 합의 | [5회 기록](stage-06-shared-dictionary/README.md) |
