# 여섯 Agent 소통 방식 · 공유용 결과 묶음

같은 일정 문제에서 여섯 방식을 5회씩 실행한 기존 30회의 결과다. 유효 합의 29회·최적 28회다. 모델을 다시 호출하지 않고 원대화·선택한 평가·수치 분석을 확인할 수 있다.

## 읽기

- [결과와 인사이트](docs/experiment-insights-v3-1.md)
- [실험 소개](docs/phase-1-experiment.md) · [지표 읽는 법](docs/metrics.md)
- [전체 비교표](results/analysis/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/comparison.md)
- [대화 사례 분석](results/analysis/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/cases.md)
- [방식별·회차별 대화](results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/README.md)
- [자연어 누락·해석 민감도](results/readable/20260911T092336Z-plan-cfd3ab2b1222-review-v3-1/language-sensitivity.md)

## 평가와 분석 재현

Python 3.9 이상만 필요하다. ZIP을 원하는 위치에 풀고 이 README가 있는 폴더에서 실행한다. Codex 로그인·네트워크·모델 호출은 필요하지 않다.

```sh
python3 scripts/verify_release.py --bundle . --output ../new-replay
```

출력은 아직 없는 새 폴더를 지정한다. 체크섬과 원본 봉인을 확인하고, 저장된 사후 평가 코드로 30회 관찰표를 재생한 뒤 비교표·요청별 비용·사례 근거를 다시 계산한다. 기존 수치와 판정이 다르면 실패한다. 결과는 출력 폴더의 `verification.json`과 `analysis/`에서 확인한다.

자연어 주석은 기존 AI 주석을 사용한다. 같은 판정의 재현은 사람의 독립 해석 검증과 다르다. 명시 오류 6건, 확인된 누락 4개, 모호한 표현 1개를 구분하며, 네 목록을 전체 목록으로 읽는 대안의 10건을 정답으로 확정하지 않는다.

## 자료의 구분

| 위치 | 내용 |
|---|---|
| `results/experiment/` | 봉인된 실행 원본과 당시 코드 |
| `results/reviews/` | 선택한 사후 평가 코드·manifest·주석·판정과 봉인 |
| `results/readable/` | 새 읽기용 사본. 각 방식의 `selected-review/`에도 실제 평가를 포함 |
| `results/analysis/` | 상대 경로를 사용한 비교표·사례·파생 데이터 |
| `execution-source/` | 공통 실행 소스 사본. 기존 실험실 운영 문서는 이 소스를 설명 |
| `reference/` | 변경하지 않은 이전 분석·경로 메타데이터. 실행 경로로 사용하지 않음 |
| `scripts/` | 이 배포 묶음의 오프라인 재현 도구 |

봉인된 기록에 들어 있는 과거 절대 경로는 출처 정보로 보존했다. 재현 명령은 상대 경로의 collection을 사용하며 원래 컴퓨터의 파일을 읽지 않는다. 평가·분석 프로세스의 Python 감사 훅은 묶음·출력·표준 라이브러리 밖의 파일 읽기와 네트워크·프로세스 실행을 차단한다. 운영체제 격리를 의미하지는 않는다.

실행기 요청/턴은 225회, 사용량 갱신은 229개다. 실제 HTTP 요청 수나 제공자 내부 호출 수는 측정하지 않았다. 비용에는 모든 누적 토큰을 포함했으며 API 단가 추정 합계는 $0.36349092다. 총비용은 미측정이다.

단일 문제·방식별 5회에 대한 관찰이다. 일반적인 방식 우열이나 실무 도입 효과까지 확정하지 않는다.
